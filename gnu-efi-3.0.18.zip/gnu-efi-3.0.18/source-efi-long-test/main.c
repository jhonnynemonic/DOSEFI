#include <efi.h>
#include <efilib.h>

void ListDirectory(EFI_FILE_PROTOCOL *dir, UINTN depth) { 
EFI_STATUS status; 
EFI_FILE_INFO *file_info; 
UINTN buffer_size; 
UINT8 *buffer; 
while (TRUE) { 
buffer_size = SIZE_OF_EFI_FILE_INFO + 256 * sizeof(CHAR16); 
buffer = AllocatePool(buffer_size); 
if (!buffer) break; 
status = uefi_call_wrapper(dir->Read, 3, dir, &buffer_size, buffer);
if (EFI_ERROR(status) || buffer_size == 0) { 
FreePool(buffer); 
break; 
} 
file_info = (EFI_FILE_INFO *)buffer;
 // Indentación visual 
for (UINTN i = 0; i < depth; i++) { 
Print(L" "); 
} 
// Mostrar nombre 
Print(L"%s", file_info->FileName);
 // Mostrar tipo y tamaño 
if (file_info->Attribute & EFI_FILE_DIRECTORY) { 
Print(L" [Dir] - %ld bytes\n", file_info->FileSize); 
// Evitar "." y ".." 
if (StrCmp(file_info->FileName, L".") != 0 && StrCmp(file_info->FileName, L"..") != 0) { 
// Abrir subdirectorio 
EFI_FILE_PROTOCOL *subdir; 
status = uefi_call_wrapper(dir->Open, 5, dir, &subdir, file_info->FileName, EFI_FILE_MODE_READ, EFI_FILE_DIRECTORY); 
if (!EFI_ERROR(status)) { ListDirectory(subdir, depth + 1); 
uefi_call_wrapper(subdir->Close, 1, subdir);
 } } } 
else { 
Print(L" [File] - %ld bytes\n", file_info->FileSize);
 } 
FreePool(buffer);
 } } 
EFI_STATUS efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) { 
EFI_STATUS status; 
EFI_LOADED_IMAGE *loaded_image; 
EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs; 
EFI_FILE_PROTOCOL *root; 
InitializeLib(ImageHandle, SystemTable); 

// Obtener protocolos 
status = uefi_call_wrapper(SystemTable->BootServices->HandleProtocol, 3, ImageHandle, &LoadedImageProtocol, (void **)&loaded_image); 
if (EFI_ERROR(status)) return status; 
status = uefi_call_wrapper(SystemTable->BootServices->HandleProtocol, 3, loaded_image->DeviceHandle, &FileSystemProtocol, (void **)&fs); 
if (EFI_ERROR(status)) return status; 
status = uefi_call_wrapper(fs->OpenVolume, 2, fs, &root); 
if (EFI_ERROR(status)) return status; 

// Recorrer raíz 
ListDirectory(root, 0);
uefi_call_wrapper(root->Close, 1, root); 
return EFI_SUCCESS; 
}