#include <efi.h>
#include <efilib.h>

void ListDirectory(EFI_FILE_PROTOCOL *dir, EFI_FILE_PROTOCOL *log, UINTN depth) {
    EFI_STATUS status;
    EFI_FILE_INFO *file_info;
    UINTN buffer_size;
    UINT8 *buffer;

    while (TRUE) {
        buffer_size = SIZE_OF_EFI_FILE_INFO + 256 * sizeof(CHAR16);
        buffer = AllocatePool(buffer_size);
        if (!buffer) break;

        status = uefi_call_wrapper(dir->Read, 3, dir, &buffer_size, buffer);
        if (EFI_ERROR(status) || buffer_size == 0) {
            FreePool(buffer);
            break;
        }

        file_info = (EFI_FILE_INFO *)buffer;

        // Construir línea de salida
        CHAR16 line[512];
        line[0] = L'\0';

        for (UINTN i = 0; i < depth; i++) {
            StrCat(line, L"  ");
        }

        StrCat(line, file_info->FileName);

        if (file_info->Attribute & EFI_FILE_DIRECTORY) {
            StrCat(line, L" [Dir] - ");
        } else {
            StrCat(line, L" [File] - ");
        }

        CHAR16 sizeStr[64];
        SPrint(sizeStr, sizeof(sizeStr), L"%ld bytes\n", file_info->FileSize);
        StrCat(line, sizeStr);

        // Escribir en archivo
        UINTN size = StrLen(line) * sizeof(CHAR16);
        uefi_call_wrapper(log->Write, 3, log, &size, line);

        // Recursión en subdirectorios
        if ((file_info->Attribute & EFI_FILE_DIRECTORY) &&
            StrCmp(file_info->FileName, L".") != 0 &&
            StrCmp(file_info->FileName, L"..") != 0) {

            EFI_FILE_PROTOCOL *subdir;
            status = uefi_call_wrapper(dir->Open, 5, dir, &subdir, file_info->FileName,
                                       EFI_FILE_MODE_READ, EFI_FILE_DIRECTORY);
            if (!EFI_ERROR(status)) {
                ListDirectory(subdir, log, depth + 1);
                uefi_call_wrapper(subdir->Close, 1, subdir);
            }
        }

        FreePool(buffer);
    }
}

EFI_STATUS efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
    EFI_STATUS status;
    EFI_LOADED_IMAGE *loaded_image;
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs;
    EFI_FILE_PROTOCOL *root, *log;

    InitializeLib(ImageHandle, SystemTable);

    // Obtener protocolos
    status = uefi_call_wrapper(SystemTable->BootServices->HandleProtocol, 3,
                               ImageHandle, &LoadedImageProtocol, (void **)&loaded_image);
    if (EFI_ERROR(status)) return status;

    status = uefi_call_wrapper(SystemTable->BootServices->HandleProtocol, 3,
                               loaded_image->DeviceHandle, &FileSystemProtocol, (void **)&fs);
    if (EFI_ERROR(status)) return status;

    status = uefi_call_wrapper(fs->OpenVolume, 2, fs, &root);
    if (EFI_ERROR(status)) return status;

    // Abrir archivo de salida
    status = uefi_call_wrapper(root->Open, 5, root, &log, L"output.txt",
                               EFI_FILE_MODE_CREATE | EFI_FILE_MODE_WRITE | EFI_FILE_MODE_READ, 0);
    if (EFI_ERROR(status)) {
        uefi_call_wrapper(root->Close, 1, root);
        return status;
    }

    // Recorrer directorios
    ListDirectory(root, log, 0);

    // Cerrar archivos
    uefi_call_wrapper(log->Close, 1, log);
    uefi_call_wrapper(root->Close, 1, root);

    return EFI_SUCCESS;
}