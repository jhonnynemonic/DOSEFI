#include <efi.h>
#include <efilib.h>

EFI_STATUS EFIAPI efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
InitializeLib(ImageHandle, SystemTable);

EFI_LOADED_IMAGE *loaded_image;
EFI_GUID loaded_image_protocol = LOADED_IMAGE_PROTOCOL;
EFI_STATUS status = uefi_call_wrapper(SystemTable->BootServices->HandleProtocol, 3, ImageHandle, &loaded_image_protocol, (void **)&loaded_image);
if (EFI_ERROR(status)) {
Print(L"Error obteniendo protocolo de imagen cargada\n");
return status;
}

EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs;
EFI_GUID fs_guid = SIMPLE_FILE_SYSTEM_PROTOCOL;
status = uefi_call_wrapper(SystemTable->BootServices->HandleProtocol, 3, loaded_image->DeviceHandle, &fs_guid, (void **)&fs);
if (EFI_ERROR(status)) {
Print(L"No se pudo obtener el sistema de archivos del CD-ROM\n");
return status;
}

EFI_FILE *root;
status = uefi_call_wrapper(fs->OpenVolume, 2, fs, &root);
if (EFI_ERROR(status)) {
Print(L"No se pudo abrir el volumen del CDROM\n");
return status;
}

Print(L"Ejecutando bootx64_message.efi...\n");
EFI_FILE *grub_file;
status = uefi_call_wrapper(root->Open, 5, root, &grub_file, L"\\EFI\\BOOT\\BOOTx64-ubuntu.EFI", EFI_FILE_MODE_READ, 0);
if (EFI_ERROR(status)) {
Print(L"No se puede abrir el archivo BOOTx64-ubuntu.EFI\n");
return status;
}

EFI_FILE_INFO *file_info;
UINTN info_size = sizeof(EFI_FILE_INFO) + 200;
file_info = AllocatePool(info_size);
status = uefi_call_wrapper(grub_file->GetInfo, 4, grub_file, &gEfiFileInfoGuid, &info_size, file_info);
if (EFI_ERROR(status)) {
Print(L"No se pudo obtener informacion de BOOTx64-ubuntu.EFI\n");
return status;
}

UINTN file_size = file_info->FileSize;
FreePool(file_info);

VOID *buffer = AllocatePool(file_size);
status = uefi_call_wrapper(grub_file->Read, 3, grub_file, &file_size,  buffer);
if (EFI_ERROR(status)) {
Print(L"No se pudo leer el fichero BOOTx64-ubuntu.EFI\n");
return status;
}

EFI_HANDLE grub_image;
status = uefi_call_wrapper(SystemTable->BootServices->LoadImage, 6, FALSE, ImageHandle, NULL, buffer, file_size, &grub_image);
if (EFI_ERROR(status)) {
Print(L"Error cargando el archivo BOOTx64-ubuntu.EFI\n");
return status;
}

status = uefi_call_wrapper(SystemTable->BootServices->StartImage, 3, grub_image, NULL, NULL);
if (EFI_ERROR(status)) {
Print(L"Error ejecutando el archivo BOOTx64-ubuntu.EFI\n");
return status;
}
return EFI_SUCCESS;
}
