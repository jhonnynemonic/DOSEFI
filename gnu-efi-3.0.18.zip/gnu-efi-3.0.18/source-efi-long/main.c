#include <efi.h>
#include <efilib.h>

EFI_STATUS efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) { 
InitializeLib(ImageHandle, SystemTable); 
Print(L" \n"); 
Print(L"################################\n"); 
Print(L"#¡Hola desde PE32+ EFI! con WSL#\n"); 
Print(L"################################\n");
Print(L" \n"); 
SystemTable->BootServices->Stall(10000000); // 10,000,000 microsegundos = 10 segundos 
return EFI_SUCCESS; }

